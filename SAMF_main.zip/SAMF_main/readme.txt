 This is the code for SAMF: Small-Area-Aware Multi-focus Image Fusion for Object Detection

 If you want to test our algorithm, please run the Demo.m, 

 the source images are in the source folder, 
 the results will be saved in the result folder.

 The functions used by the algorithm are in the Function folder, so be sure to add them to the Matlab path before running our algorithm!

 Our Road-MF dataset can be downloaded at the following link, please cite our paper above when using it, thanks!

  Baidu online disk：https://pan.baidu.com/s/1J2XfS_eGD2muMaS-UUu6Hg 
  Extraction code：fosu 

 Google cloud drive：https://drive.google.com/drive/folders/1D1EmUttkGvwG0CGZFHpBbmtndWQLkM3z?usp=sharing