function [Fmap,IFF]=main3(f1,f2)

   [row,column]=size(f1);

%%
fh=zeros(row,column);
h11=zeros(row,column);
h22=zeros(row,column);

 for k=1:5
    G=fspecial('gaussian',k,23);
    b1=imfilter(f1,G,'same');
    b2=imfilter(f2,G,'same');

   h1=f1-b1;
   h2=f2-b2;
   h11=h1+h11;
   h22=h2+h22;

 end

    ss1 = ssq(h11);
    ss2 = ssq(h22);

     if ss1-ss2>0.04
         mapp=abs(h11>h22);
         fh=mapp.*h11+(1-mapp).*h22;
     else ss1-ss2<=0.04;
         fh=(ss1/(ss1+ss2)).*h11+(ss2/(ss1+ss2)).*h22;
     end
         


%%
weight1 = Visual_Weight_Map(b1);
weight2 = Visual_Weight_Map(b2);
IB = (0.5+0.5*(weight1-weight2)).*f1 + (0.5+0.5*(weight2-weight1)).*f2;

 IFF=double(IB+fh);


[mssim1, FM1] = ssim(IFF,f1);
[mssim2, FM2] = ssim(IFF,f2);


  BA = RF(FM1, 5 , 0.25, 3, f1);
  BB = RF(FM2, 5 , 0.25, 3, f2);

  map2=abs(BA>BB);


  map2 = majority_consist_new(map2,23);





  DB=abs(BA-BB);
  DD=FM1-FM2;
  BD =abs(RF(DD, 2 , 0.2, 3, f1));  %3 0.25 3


map=zeros(row,column);
Fmap=zeros(row,column);
 for i=1:row
    for  j=1:column  
        if DB(i,j)>0.5*BD(i,j) && BA(i,j)>BB(i,j)
            map(i,j)=1;
        elseif DB(i,j)>0.5*BD(i,j) && BA(i,j)<=BB(i,j)
            map(i,j)=2;
        else DB(i,j)<=0.5*BD(i,j);
             map(i,j)=0;
        
       end
    end   
 end
 %figure,imshow(map);



 for i=1:row
    for  j=1:column  
        if map(i,j)==1 && map2(i,j)==1
            Fmap(i,j)=1;
        elseif map(i,j)==2 && map2(i,j)==0
            Fmap(i,j)=0;
        elseif map(i,j)==0
             Fmap(i,j)=0.5;
        else 
             Fmap(i,j)=0.5;

        end
    end
 end
