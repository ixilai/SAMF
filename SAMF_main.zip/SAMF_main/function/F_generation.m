function F=F_generation(f1,f2,Fmap)

[row,column]=size(f1);
f1=im2double(f1);
f2=im2double(f2);
F=zeros(row,column);

weight1 = Visual_Weight_Map(f1);
weight2 = Visual_Weight_Map(f2);
IF = (0.5+0.5*(weight1-weight2)).*f1 + (0.5+0.5*(weight2-weight1)).*f2;

  for i=1:row
    for  j=1:column  
        if Fmap(i,j)==1
            F(i,j)=f1(i,j);
        elseif Fmap(i,j)==0
             F(i,j)=f2(i,j);
        else
            F(i,j)=IF(i,j);

        end
    end
 end
%figure,imshow(F);