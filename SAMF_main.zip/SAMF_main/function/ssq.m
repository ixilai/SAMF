function ss = ssq(bands)
lh_img = bands.^2;
ss = log10(1+mean(lh_img(:)));